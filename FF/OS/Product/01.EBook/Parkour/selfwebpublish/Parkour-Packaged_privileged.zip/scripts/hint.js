/* Instructions */

// var value = navigator.mozPermissionsettings.set("video-capture", "prompt", manifest.webapp, origin, browserFlag)

alert("使用说明: 首先，确保终端开启了摄像头权限，以便在前置摄像头前通过手势完成向左/右翻页动作；也可通过在页面上分别点击左右方向键来进行向左/右翻页操作，每页多余内容可以在屏幕上向上/下滑动进行查看。");